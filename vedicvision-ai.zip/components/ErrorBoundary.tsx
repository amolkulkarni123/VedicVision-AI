
import React, { Component, ErrorInfo, ReactNode } from 'react';
import { ShieldAlert, RotateCcw, AlertTriangle } from 'lucide-react';

interface Props {
  // Fix: Make children optional to avoid 'missing' error in JSX usage when used as a wrapper in some environments
  children?: ReactNode;
}

interface State {
  hasError: boolean;
  error?: Error;
  errorType: 'API' | 'RUNTIME' | 'NETWORK';
}

// Fix: Use Component directly from named import to ensure state and props are correctly inherited and recognized by the compiler
class ErrorBoundary extends Component<Props, State> {
  constructor(props: Props) {
    super(props);
    // Fix: Correctly initialize state in constructor
    this.state = {
      hasError: false,
      errorType: 'RUNTIME'
    };
  }

  public static getDerivedStateFromError(error: Error): State {
    // Detect API errors vs UI crashes
    const isApiError = error.message.includes('Gemini') || error.message.includes('API');
    return { 
      hasError: true, 
      error, 
      errorType: isApiError ? 'API' : 'RUNTIME' 
    };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error("VedicVision Production Crash:", error, errorInfo);
  }

  public render() {
    // Fix: state and props are now correctly typed and accessible through inheritance
    const { hasError, errorType } = this.state;
    const { children } = this.props;

    if (hasError) {
      return (
        <div className="min-h-[400px] flex items-center justify-center p-8 bg-vedic-paper rounded-[3rem] border-8 border-rose-200 text-center shadow-2xl">
          <div className="max-w-md">
            <div className="mb-6 relative inline-block">
              <ShieldAlert className="w-20 h-20 text-rose-500 mx-auto animate-pulse" />
              <div className="absolute -top-2 -right-2 bg-rose-600 text-white p-2 rounded-full shadow-lg">
                <AlertTriangle className="w-4 h-4" />
              </div>
            </div>
            
            <h2 className="text-3xl font-serif font-bold text-vedic-primary mb-2">
              {errorType === 'API' ? 'Planetary Alignment Delayed' : 'Celestial Interference'}
            </h2>
            <p className="text-vedic-secondary mb-8 italic text-sm">
              {errorType === 'API' 
                ? 'The cosmic archives are temporarily locked. Our Rishis are attempting a reconnection.' 
                : 'A rare scriptural conflict has caused a temporary disruption in your destiny path.'}
            </p>
            
            <div className="flex flex-col gap-3">
              <button
                onClick={() => window.location.reload()}
                className="flex items-center justify-center gap-2 px-8 py-4 bg-vedic-primary text-vedic-gold rounded-full font-bold shadow-2xl hover:scale-105 transition-all"
              >
                <RotateCcw className="w-5 h-5" /> Restore Sanctity
              </button>
              <button
                onClick={() => { localStorage.removeItem('vv_birth_details'); window.location.reload(); }}
                className="text-[10px] uppercase font-black text-rose-600 underline opacity-60 hover:opacity-100"
              >
                Reset App & Clear Records
              </button>
            </div>
          </div>
        </div>
      );
    }

    return children;
  }
}

export default ErrorBoundary;

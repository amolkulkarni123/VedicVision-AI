
import React from 'react';
import { ArrowLeft, Loader2 } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { ASSETS } from '../constants';

export const PalmLeafCard: React.FC<{ children: React.ReactNode; className?: string; contentClassName?: string }> = ({ 
  children, 
  className = '', 
  contentClassName = 'px-6 sm:px-12 py-8' 
}) => (
  <div className={`relative bg-vedic-paper border-y-[6px] border-vedic-accent shadow-2xl overflow-hidden rounded-lg group transition-transform hover:scale-[1.002] ${className}`}>
    <div className="absolute inset-0 opacity-20 pointer-events-none mix-blend-multiply" 
         style={{ backgroundImage: `url(${ASSETS.TEXTURE}), url("https://www.transparenttextures.com/patterns/wood-pattern.png")` }}>
    </div>
    <div className="absolute top-0 left-0 w-12 h-12 border-t-4 border-l-4 border-vedic-highlight rounded-tl-xl opacity-80"></div>
    <div className="absolute bottom-0 right-0 w-12 h-12 border-b-4 border-r-4 border-vedic-highlight rounded-br-xl opacity-80"></div>
    <div className={`relative z-10 ${contentClassName}`}>{children}</div>
  </div>
);

export const BackButton: React.FC<{ onBack: () => void }> = ({ onBack }) => (
  <button 
    onClick={onBack} 
    className="mb-6 flex items-center gap-2 px-4 py-2 bg-vedic-paper border-2 border-vedic-accent rounded-lg text-vedic-primary font-bold shadow-md hover:bg-vedic-gold transition-all"
  >
    <ArrowLeft className="w-4 h-4" /> Return to Dashboard
  </button>
);

export const LoadingOverlay: React.FC = () => (
  <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm">
     <div className="bg-vedic-light p-8 rounded-lg shadow-xl text-center border-2 border-vedic-accent">
        <Loader2 className="w-12 h-12 animate-spin text-vedic-accent mx-auto mb-4"/>
        <p className="text-vedic-primary font-serif font-bold text-lg">Consulting the Cosmic Archives...</p>
        <p className="text-vedic-secondary text-sm mt-2 italic">Gemini is aligning the stars</p>
     </div>
  </div>
);

export const renderSafe = (content: any): React.ReactNode => {
  if (content === null || content === undefined) return "";
  if (typeof content === 'string') {
    return <ReactMarkdown className="prose prose-sm leading-relaxed text-vedic-primary">{content}</ReactMarkdown>;
  }
  if (typeof content === 'number') return String(content);
  if (Array.isArray(content)) return content.map((item, i) => <React.Fragment key={i}>{renderSafe(item)}{i < content.length - 1 ? ", " : ""}</React.Fragment>);
  if (typeof content === 'object') {
     return Object.entries(content).map(([k,v], i) => <div key={i}><span className="font-bold">{k}:</span> {renderSafe(v)}</div>);
  }
  return "";
};

import React from 'react';
import ReactMarkdown from 'react-markdown';
import { Bot, User, AlertCircle } from 'lucide-react';
import { Message } from '../types';

interface MessageBubbleProps {
  message: Message;
}

const MessageBubble: React.FC<MessageBubbleProps> = ({ message }) => {
  const isUser = message.role === 'user';
  const isError = message.isError;

  return (
    <div className={`flex w-full mb-6 ${isUser ? 'justify-end' : 'justify-start'}`}>
      <div className={`flex max-w-4xl w-full gap-4 ${isUser ? 'flex-row-reverse' : 'flex-row'}`}>
        
        {/* Avatar */}
        <div className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center mt-1 
          ${isUser ? 'bg-gray-200' : 'bg-gradient-to-br from-blue-500 to-purple-600'}`}>
          {isUser ? (
            <User className="w-5 h-5 text-gray-600" />
          ) : (
            <Bot className="w-5 h-5 text-white" />
          )}
        </div>

        {/* Content */}
        <div className={`flex-1 min-w-0 flex flex-col items-start ${isUser ? 'items-end' : 'items-start'}`}>
          <div className="flex flex-col gap-2">
            
            {/* Attachments */}
            {message.attachments && message.attachments.length > 0 && (
              <div className="flex flex-wrap gap-2 mb-2 justify-end">
                {message.attachments.map((att, idx) => (
                  <div key={idx} className="relative group rounded-lg overflow-hidden border border-gray-200">
                    <img 
                      src={att.previewUrl} 
                      alt="Attachment" 
                      className="h-32 w-auto object-cover" 
                    />
                  </div>
                ))}
              </div>
            )}

            {/* Text Bubble */}
            <div 
              className={`px-5 py-3 rounded-2xl text-sm md:text-base leading-relaxed overflow-hidden
              ${isError 
                ? 'bg-red-50 text-red-800 border border-red-200' 
                : isUser 
                  ? 'bg-gray-100 text-gray-800 rounded-tr-sm' 
                  : 'text-gray-900 bg-transparent px-0 py-0' // Model messages are plain markdown without bubble bg
              }`}
            >
              {isError && (
                 <div className="flex items-center gap-2 mb-1 font-semibold">
                   <AlertCircle className="w-4 h-4" />
                   <span>Error generating response</span>
                 </div>
              )}

              {isUser ? (
                <div className="whitespace-pre-wrap">{message.text}</div>
              ) : (
                <div className="markdown-content">
                  <ReactMarkdown>{message.text}</ReactMarkdown>
                </div>
              )}
            </div>

            {/* Timestamp / Meta */}
            <div className={`text-xs text-gray-400 mt-1 ${isUser ? 'text-right' : 'text-left'}`}>
              {new Date(message.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MessageBubble;
import React from 'react';
import { Sparkles, ChevronDown, Check, Trash2, Github } from 'lucide-react';
import { ModelId } from '../types';
import { MODEL_OPTIONS } from '../constants';

interface HeaderProps {
  currentModel: ModelId;
  onModelChange: (model: ModelId) => void;
  onClearChat: () => void;
}

const Header: React.FC<HeaderProps> = ({ currentModel, onModelChange, onClearChat }) => {
  const [isOpen, setIsOpen] = React.useState(false);
  const dropdownRef = React.useRef<HTMLDivElement>(null);

  const selectedModelName = MODEL_OPTIONS.find(m => m.id === currentModel)?.name || 'Select Model';

  React.useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  return (
    <header className="fixed top-0 left-0 right-0 bg-white/80 backdrop-blur-md z-50 border-b border-gray-100 h-16 flex items-center justify-between px-4 lg:px-8">
      <div className="flex items-center gap-2">
        <span className="text-xl font-medium text-gray-700 tracking-tight flex items-center gap-2">
          Gemini
          <span className="text-xs bg-gradient-to-r from-blue-500 to-purple-500 text-transparent bg-clip-text font-bold uppercase tracking-wider border border-blue-100 rounded px-1.5 py-0.5">
            2.0
          </span>
        </span>
        
        {/* Model Selector */}
        <div className="relative ml-6" ref={dropdownRef}>
          <button 
            onClick={() => setIsOpen(!isOpen)}
            className="flex items-center gap-2 text-sm font-medium text-gray-600 hover:bg-gray-100 px-3 py-1.5 rounded-lg transition-colors"
          >
            {selectedModelName}
            <ChevronDown className={`w-4 h-4 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
          </button>

          {isOpen && (
            <div className="absolute top-full left-0 mt-2 w-64 bg-white rounded-xl shadow-xl border border-gray-100 p-1 py-2 overflow-hidden animate-in fade-in zoom-in-95 duration-100">
              <div className="px-3 py-2 text-xs font-semibold text-gray-400 uppercase tracking-wider">
                Model Version
              </div>
              {MODEL_OPTIONS.map((option) => (
                <button
                  key={option.id}
                  onClick={() => {
                    onModelChange(option.id);
                    setIsOpen(false);
                  }}
                  className="w-full text-left px-3 py-2.5 hover:bg-gray-50 rounded-lg flex items-start gap-3 transition-colors group"
                >
                  <div className={`mt-0.5 p-1 rounded ${currentModel === option.id ? 'bg-blue-100 text-blue-600' : 'bg-gray-100 text-gray-500 group-hover:text-gray-700'}`}>
                    <Sparkles className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-sm font-medium text-gray-800 flex items-center gap-2">
                      {option.name}
                      {currentModel === option.id && <Check className="w-3 h-3 text-blue-600" />}
                    </div>
                    <div className="text-xs text-gray-500 mt-0.5">
                      {option.description}
                    </div>
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      <div className="flex items-center gap-2">
        <button 
          onClick={onClearChat}
          className="p-2 text-gray-500 hover:text-red-600 hover:bg-red-50 rounded-full transition-colors"
          title="Clear Chat"
        >
          <Trash2 className="w-5 h-5" />
        </button>
      </div>
    </header>
  );
};

export default Header;
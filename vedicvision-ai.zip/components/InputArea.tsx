import React, { useState, useRef, useEffect } from 'react';
import { Send, Image as ImageIcon, X, Loader2 } from 'lucide-react';
import { Attachment } from '../types';

interface InputAreaProps {
  onSend: (text: string, attachments: Attachment[]) => void;
  isLoading: boolean;
}

const InputArea: React.FC<InputAreaProps> = ({ onSend, isLoading }) => {
  const [text, setText] = useState('');
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 200)}px`;
    }
  }, [text]);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleSend = () => {
    if ((!text.trim() && attachments.length === 0) || isLoading) return;
    
    onSend(text, attachments);
    setText('');
    setAttachments([]);
    
    // Reset height
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const newAttachments: Attachment[] = [];
      // Fix: Explicitly type 'file' as 'File' to avoid 'unknown' type errors
      Array.from(e.target.files).forEach((file: File) => {
        // Validate image type
        if (!file.type.startsWith('image/')) return;

        const reader = new FileReader();
        reader.onload = (event) => {
          if (event.target?.result) {
            newAttachments.push({
              file,
              previewUrl: URL.createObjectURL(file),
              base64: event.target.result as string,
              mimeType: file.type
            });
            // Update state when all processed (simplified for this example, usually tracking promises is better)
            if (newAttachments.length === e.target.files!.length) {
              setAttachments(prev => [...prev, ...newAttachments]);
            }
          }
        };
        reader.readAsDataURL(file);
      });
    }
    // Reset input
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const removeAttachment = (index: number) => {
    setAttachments(prev => prev.filter((_, i) => i !== index));
  };

  return (
    <div className="w-full max-w-4xl mx-auto p-4">
      {/* Attachment Previews */}
      {attachments.length > 0 && (
        <div className="flex gap-3 mb-3 overflow-x-auto py-2 px-1">
          {attachments.map((att, i) => (
            <div key={i} className="relative group flex-shrink-0">
              <img 
                src={att.previewUrl} 
                alt="preview" 
                className="h-20 w-20 object-cover rounded-lg border border-gray-200 shadow-sm"
              />
              <button 
                onClick={() => removeAttachment(i)}
                className="absolute -top-2 -right-2 bg-gray-800 text-white rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity"
              >
                <X className="w-3 h-3" />
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Input Box */}
      <div className="relative flex items-end gap-2 bg-gray-100/80 rounded-[28px] p-2 border border-transparent focus-within:border-gray-300 focus-within:bg-white focus-within:shadow-md transition-all duration-200">
        
        <button 
          onClick={() => fileInputRef.current?.click()}
          className="p-3 text-gray-500 hover:text-gray-800 hover:bg-gray-200 rounded-full transition-colors flex-shrink-0"
          title="Add image"
          disabled={isLoading}
        >
          <ImageIcon className="w-5 h-5" />
        </button>
        <input 
          type="file" 
          ref={fileInputRef} 
          className="hidden" 
          accept="image/*" 
          multiple 
        />

        <textarea
          ref={textareaRef}
          value={text}
          onChange={(e) => setText(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Ask Gemini..."
          disabled={isLoading}
          className="w-full bg-transparent border-none outline-none resize-none py-3 max-h-[200px] text-gray-800 placeholder-gray-500 font-sans"
          rows={1}
        />

        <button 
          onClick={handleSend}
          disabled={isLoading || (!text.trim() && attachments.length === 0)}
          className={`p-3 rounded-full transition-all duration-200 flex-shrink-0
            ${(text.trim() || attachments.length > 0) && !isLoading 
              ? 'bg-blue-600 text-white hover:bg-blue-700 shadow-sm' 
              : 'bg-transparent text-gray-400 cursor-not-allowed'
            }`}
        >
          {isLoading ? (
            <Loader2 className="w-5 h-5 animate-spin" />
          ) : (
            <Send className="w-5 h-5" />
          )}
        </button>
      </div>
      
      <div className="text-center mt-2">
        <p className="text-xs text-gray-400">
          Gemini may display inaccurate info, including about people, so double-check its responses.
        </p>
      </div>
    </div>
  );
};

export default InputArea;
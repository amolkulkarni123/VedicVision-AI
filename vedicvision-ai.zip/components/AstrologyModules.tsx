
import React, { useState, useEffect, useRef } from 'react';
import { 
  Sun, Star, Compass, Briefcase, Heart, Activity, Clock, 
  Send, Upload, Globe, RotateCw, Sparkles, Zap, Gem,
  Target, Video, Play, ExternalLink, Brain, 
  Users, Hand, Flame, BookOpen, Scroll, Music, 
  CalendarDays, HeartPulse, User, Bot, Image as ImageIcon, 
  FlameKindling, Stars, Info, AlertCircle, CheckCircle2, Search
} from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { 
  VargaCharts, YearlyForecast, MatchResult, 
  PalmistryResult, ChartData, DailyHoroscopeData, 
  CouncilWisdom, ResearchResult, UserBirthDetails, RemedyData, LoshuGridData, Message, Attachment
} from '../types';
import { PalmLeafCard, BackButton } from './Shared';
import { GeminiService } from '../services/geminiService';
import MessageBubble from './MessageBubble';
import InputArea from './InputArea';

const Mandala = ({ className }: { className?: string }) => (
  <svg viewBox="0 0 100 100" className={className} fill="currentColor">
    <path d="M50 0C22.4 0 0 22.4 0 50s22.4 50 50 50 50-22.4 50-50S77.6 0 50 0zm0 90C27.9 90 10 72.1 10 50S27.9 10 50 10s40 17.9 40 40-17.9 40-40 40z" opacity=".2"/>
    <path d="M50 20c-16.5 0-30 13.5-30 30s13.5 30 30 30 30-13.5 30-30-13.5-30-30-30zm0 50c-11 0-20-9-20-20s9-20 20-20 20 9 20 20-9 20-20 20z" opacity=".4"/>
    <path d="M50 35c-8.3 0-15 6.7-15 15s6.7 15 15 15 15-6.7 15-15-6.7-15-15-15zm0 20c-2.8 0-5-2.2-5-5s2.2-5 5-5 5 2.2 5 5-2.2 5-5 5z" opacity=".6"/>
  </svg>
);

// --- Loshu Grid Component ---
export const LoshuGrid: React.FC<{ data: LoshuGridData }> = ({ data }) => {
  const gridPositions = [4, 9, 2, 3, 5, 7, 8, 1, 6];
  
  // Calculate counts for intensity display
  const counts = data.grid.reduce((acc: any, val) => {
    if (val !== null) acc[val] = (acc[val] || 0) + 1;
    return acc;
  }, {});
  
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-3 aspect-square max-w-[280px] mx-auto border-4 border-vedic-primary rounded-xl overflow-hidden shadow-2xl">
        {gridPositions.map((num, idx) => {
          const count = counts[num] || 0;
          return (
            <div key={idx} className={`relative flex flex-col items-center justify-center border border-vedic-gold/20 transition-all
              ${count > 0 ? 'bg-vedic-primary text-vedic-gold' : 'bg-vedic-paper text-vedic-primary/10'}`}>
              <span className={`font-serif font-bold ${count > 1 ? 'text-3xl' : 'text-2xl'}`}>
                {count > 0 ? num : ''}
              </span>
              {count > 1 && (
                <span className="absolute bottom-1 right-2 text-[10px] font-black opacity-60">
                  x{count}
                </span>
              )}
            </div>
          );
        })}
      </div>
      <div className="bg-white/50 p-4 rounded-xl border border-vedic-gold/20 text-xs">
        <h4 className="font-serif font-bold text-vedic-primary mb-2 flex items-center gap-2 text-sm">
           <Zap className="w-4 h-4 text-vedic-accent" /> Numerological Insight
        </h4>
        <p className="italic text-vedic-secondary leading-relaxed">{data.missingNumbersAnalysis}</p>
        <div className="mt-3 flex flex-wrap gap-2">
           {data.strengths.map((s, i) => <span key={i} className="bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full font-bold">+{s}</span>)}
           {data.weaknesses.map((w, i) => <span key={i} className="bg-rose-100 text-rose-800 px-2 py-0.5 rounded-full font-bold">-{w}</span>)}
        </div>
      </div>
    </div>
  );
};

// --- South Indian Chart Component ---
export const SouthIndianChart: React.FC<{ charts: VargaCharts }> = ({ charts }) => {
  const [activeChart, setActiveChart] = useState<'d1' | 'd9' | 'd10'>('d1');
  const data = charts?.[activeChart] || [];
  
  const getPlanetsForSign = (sign: string) => {
    return data.filter(p => p.sign && p.sign.toLowerCase().includes(sign.toLowerCase())).map(p => p.planet);
  };

  const gridSigns = [
    { name: "Pisces", index: 0 }, { name: "Aries", index: 1 }, { name: "Taurus", index: 2 }, { name: "Gemini", index: 3 },
    { name: "Cancer", index: 7 }, { name: "Leo", index: 11 }, { name: "Virgo", index: 15 }, { name: "Libra", index: 14 },
    { name: "Scorpio", index: 13 }, { name: "Sagittarius", index: 12 }, { name: "Capricorn", index: 8 }, { name: "Aquarius", index: 4 }
  ];

  const grid = Array(16).fill(null);
  gridSigns.forEach(gs => grid[gs.index] = gs.name);

  return (
    <div className="w-full max-w-md mx-auto">
      <div className="flex justify-center gap-2 mb-4">
        {['d1', 'd9', 'd10'].map((c) => (
          <button key={c} onClick={() => setActiveChart(c as any)} 
            className={`px-4 py-1.5 text-xs font-bold rounded-full border-2 transition-all 
            ${activeChart === c ? 'bg-vedic-highlight text-white border-vedic-highlight shadow-lg' : 'bg-vedic-paper text-vedic-primary border-vedic-secondary hover:bg-white'}`}>
            {c.toUpperCase()}
          </button>
        ))}
      </div>
      <div className="aspect-square bg-vedic-paper border-[8px] border-vedic-secondary shadow-2xl p-1 relative rounded-xl">
        <div className="grid grid-cols-4 grid-rows-4 w-full h-full gap-1 bg-vedic-secondary/20">
          {grid.map((signName, idx) => {
            if ([5, 6, 9, 10].includes(idx)) {
               if (idx === 5) return <div key={idx} className="col-span-2 row-span-2 bg-vedic-light/50 flex flex-col items-center justify-center border-double border-4 border-vedic-gold">
                  <span className="text-vedic-highlight font-serif text-3xl font-bold">{activeChart.toUpperCase()}</span>
                  <span className="text-[10px] text-vedic-primary font-bold opacity-60 uppercase">Varga</span>
               </div>;
               return null;
            }
            const planets = signName ? getPlanetsForSign(signName) : [];
            return (
              <div key={idx} className="bg-white/80 relative p-1 flex flex-col items-center justify-center border border-vedic-secondary/10 hover:bg-white transition-colors">
                {signName && (
                  <>
                    <span className="absolute top-1 right-1 text-[8px] uppercase text-vedic-accent font-black tracking-tighter">{signName.substring(0,3)}</span>
                    <div className="flex flex-wrap gap-1 justify-center mt-1">
                      {planets.map((p, i) => (
                        <span key={i} title={p} className="text-[10px] font-bold px-1.5 py-0.5 rounded-sm bg-vedic-primary text-white shadow-sm">
                          {p.substring(0, 2)}
                        </span>
                      ))}
                    </div>
                  </>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

// --- Prediction Panel ---
export const PredictionPanel: React.FC<{ forecasts: YearlyForecast[], chart?: ChartData, lang?: string, onBack: () => void }> = ({ forecasts, chart, lang, onBack }) => {
  const currentYearVal = new Date().getFullYear();
  const currentMonthVal = new Date().getMonth();
  const currentDateVal = new Date().getDate();

  const [selectedYear, setSelectedYear] = useState(currentYearVal);
  const [selectedMonth, setSelectedMonth] = useState(currentMonthVal);
  const [selectedDate, setSelectedDate] = useState(currentDateVal);
  const [detailedInsight, setDetailedInsight] = useState<string | null>(null);
  const [loadingInsight, setLoadingInsight] = useState(false);

  const months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
  const years = Array.from({ length: 6 }, (_, i) => currentYearVal + i);
  const daysInMonth = new Date(selectedYear, selectedMonth + 1, 0).getDate();
  const dayOptions = Array.from({ length: daysInMonth }, (_, i) => i + 1);

  const activeYearData = forecasts.find(f => f.year === selectedYear);
  const activeMonthData = activeYearData?.months.find(m => m.monthName.toLowerCase() === months[selectedMonth].toLowerCase());

  const getSpecificDateInsight = async () => {
    if (!chart || !lang) return;
    setLoadingInsight(true);
    setDetailedInsight(null);
    try {
      const dateString = `${selectedDate} ${months[selectedMonth]} ${selectedYear}`;
      const response = await GeminiService.chatStream([], `Provide a detailed Vedic insight for ${dateString} based on ${chart.ascendant} ascendant. Include a Sanskrit sutra.`, lang);
      let fullText = "";
      for await (const chunk of response) {
        fullText += chunk.text;
        setDetailedInsight(fullText);
      }
    } catch (e) {
      setDetailedInsight("Celestial interference. Try again.");
    } finally {
      setLoadingInsight(false);
    }
  };

  return (
    <div className="animate-fade-in pb-16 space-y-8">
      <BackButton onBack={onBack} />
      <div className="flex flex-col md:flex-row items-center justify-between gap-6 p-6 bg-white border-2 border-vedic-gold rounded-3xl shadow-xl">
        <div className="flex items-center gap-3">
          <CalendarDays className="w-6 h-6 text-vedic-primary" />
          <h2 className="text-2xl font-serif font-bold text-vedic-primary">Bhavishya Phala</h2>
        </div>
        <div className="flex flex-wrap gap-2">
          <select value={selectedYear} onChange={e => setSelectedYear(Number(e.target.value))} className="bg-vedic-light border-2 border-vedic-gold rounded-xl px-4 py-2 text-sm font-bold text-vedic-primary">
            {years.map(y => <option key={y} value={y}>{y}</option>)}
          </select>
          <select value={selectedMonth} onChange={e => setSelectedMonth(Number(e.target.value))} className="bg-vedic-light border-2 border-vedic-gold rounded-xl px-4 py-2 text-sm font-bold text-vedic-primary">
            {months.map((m, i) => <option key={m} value={i}>{m}</option>)}
          </select>
          <select value={selectedDate} onChange={e => setSelectedDate(Number(e.target.value))} className="bg-vedic-light border-2 border-vedic-gold rounded-xl px-4 py-2 text-sm font-bold text-vedic-primary">
            {dayOptions.map(d => <option key={d} value={d}>{d}</option>)}
          </select>
        </div>
      </div>

      <div className="grid lg:grid-cols-12 gap-8">
        <div className="lg:col-span-5 space-y-6">
          <PalmLeafCard className="rounded-3xl border-vedic-highlight shadow-lg">
            <h3 className="text-xl font-serif font-bold text-vedic-primary mb-2 flex items-center gap-2">
              <Stars className="w-5 h-5 text-vedic-highlight" /> Yearly Decree
            </h3>
            <p className="text-sm italic text-vedic-secondary leading-relaxed">{activeYearData?.overview || "Cycles processing..."}</p>
          </PalmLeafCard>
          <PalmLeafCard className="rounded-3xl border-vedic-accent shadow-lg">
            <h3 className="text-xl font-serif font-bold text-vedic-primary mb-2 flex items-center gap-2">
              <FlameKindling className="w-5 h-5 text-vedic-accent" /> Monthly Analysis
            </h3>
            <p className="text-sm text-vedic-primary italic leading-relaxed">{activeMonthData?.prediction || "Report pending..."}</p>
          </PalmLeafCard>
        </div>
        <div className="lg:col-span-7">
          <PalmLeafCard className="rounded-3xl border-4 border-vedic-gold bg-white shadow-2xl min-h-[500px] flex flex-col p-0 overflow-hidden">
             <div className="bg-vedic-primary p-6 text-white flex justify-between items-center">
                <h4 className="text-lg font-serif font-bold">The Daily Oracle</h4>
                <button onClick={getSpecificDateInsight} className="bg-vedic-accent px-4 py-1 rounded-full text-xs font-bold shadow-md hover:scale-105 transition-all">
                  Invoke Day Vision
                </button>
             </div>
             <div className="flex-1 p-8 bg-[#fffdfa] overflow-y-auto">
                {loadingInsight ? (
                  <div className="flex flex-col items-center justify-center h-full gap-4">
                    <RotateCw className="w-12 h-12 text-vedic-accent animate-spin" />
                    <p className="font-serif italic text-vedic-primary">Reading the scrolls...</p>
                  </div>
                ) : detailedInsight ? (
                  <ReactMarkdown className="prose prose-sm text-vedic-primary leading-relaxed prose-headings:font-serif">{detailedInsight}</ReactMarkdown>
                ) : (
                  <div className="flex flex-col items-center justify-center h-full opacity-30">
                    <Info className="w-16 h-16 mb-4" />
                    <p className="text-xl font-serif italic">Invoke the Oracle for today's Sanskrit-grounded reading.</p>
                  </div>
                )}
             </div>
          </PalmLeafCard>
        </div>
      </div>
    </div>
  );
};

// --- Chat Interface ---
export const ChatInterface: React.FC<{ initialContext: string, lang: string, onBack: () => void }> = ({ initialContext, lang, onBack }) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => { scrollRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages]);

  const handleSend = async (text: string, attachments: Attachment[]) => {
    const userMsg: Message = { role: 'user', text, timestamp: Date.now(), attachments };
    setMessages(prev => [...prev, userMsg]);
    setLoading(true);

    try {
      const history = messages.map(m => ({ role: m.role, parts: [{ text: m.text }] }));
      const stream = await GeminiService.chatStream(history, text, lang);
      let fullText = '';
      
      setMessages(prev => [...prev, { role: 'model', text: '', timestamp: Date.now() }]);

      for await (const chunk of stream) {
        fullText += chunk.text;
        setMessages(prev => {
          const newMessages = [...prev];
          newMessages[newMessages.length - 1].text = fullText;
          return newMessages;
        });
      }
    } catch (e) {
      setMessages(prev => [...prev, { role: 'model', text: "Cosmic portal closed. Try again.", timestamp: Date.now(), isError: true }]);
    } finally { setLoading(false); }
  };

  return (
    <div className="flex flex-col h-[750px] bg-white rounded-[3rem] border-8 border-vedic-gold overflow-hidden shadow-2xl relative">
      <div className="bg-vedic-primary p-6 text-white flex justify-between items-center relative z-10 shadow-lg">
         <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-vedic-gold rounded-full flex items-center justify-center text-vedic-primary font-bold shadow-inner">ॐ</div>
            <h3 className="font-serif font-bold text-lg">Rishi AI Consultation</h3>
         </div>
         <button onClick={onBack} className="text-[10px] font-black border border-white/30 px-4 py-2 rounded-full hover:bg-white/10">Exit Temple</button>
      </div>

      <div className="flex-1 overflow-y-auto p-8 bg-[#fffdfa] custom-scrollbar">
         {messages.length === 0 && (
           <div className="text-center py-20 opacity-40 italic font-serif space-y-4">
              <Mandala className="w-24 h-24 mx-auto text-vedic-accent opacity-20 animate-spin-slow" />
              <p className="text-2xl">The Rishi awaits your query, Seeker.</p>
           </div>
         )}
         {messages.map((m, i) => (
           <MessageBubble key={i} message={m} />
         ))}
         <div ref={scrollRef} />
      </div>

      <div className="border-t-4 border-vedic-gold/20 bg-vedic-light/50">
         <InputArea onSend={handleSend} isLoading={loading} />
      </div>
    </div>
  );
};

// --- Today Horoscope ---
export const TodayHoroscope: React.FC<{ chart: ChartData, lang: string, onBack: () => void }> = ({ chart, lang, onBack }) => {
  const [data, setData] = useState<DailyHoroscopeData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetch = async () => {
      setLoading(true);
      try {
        const result = await GeminiService.generateDailyHoroscope(chart, lang);
        if (result) setData(result);
      } catch (e) { 
        console.error(e); 
      } finally { 
        setLoading(false); 
      }
    };
    fetch();
  }, [chart, lang]);

  return (
    <div className="animate-fade-in pb-12">
      <BackButton onBack={onBack} />
      <PalmLeafCard className="max-w-4xl mx-auto rounded-3xl overflow-hidden p-0 shadow-2xl border-vedic-primary">
        <div className="bg-gradient-to-r from-vedic-primary to-vedic-secondary p-12 text-center text-white">
           <Sun className="w-16 h-16 mx-auto mb-4 text-vedic-gold animate-spin-slow" />
           <h2 className="text-4xl font-serif font-bold mb-2">Today's Gochara</h2>
           <p className="text-xs opacity-70 uppercase tracking-[0.2em]">Real-time Planetary alignment for Your Soul</p>
        </div>
        <div className="p-10 bg-[#fffdfa] space-y-8 min-h-[400px]">
           {loading ? (
             <div className="py-20 flex flex-col items-center">
                <RotateCw className="w-12 h-12 text-vedic-accent animate-spin mb-4" />
                <p className="font-serif italic text-vedic-primary">Consulting the morning constellations...</p>
             </div>
           ) : data ? (
             <div className="space-y-8 animate-fade-in">
               <div className="text-center bg-vedic-paper/30 p-8 rounded-2xl border-2 border-vedic-gold shadow-inner relative overflow-hidden">
                  <Mandala className="absolute inset-0 opacity-5 pointer-events-none" />
                  <h3 className="text-[10px] font-black text-vedic-accent uppercase tracking-[0.4em] mb-4">Cosmic Sutra</h3>
                  <p className="text-2xl font-serif font-bold italic leading-relaxed text-vedic-primary">"{data.scriptureSutra}"</p>
               </div>

               <div className="grid md:grid-cols-12 gap-8 items-start">
                  <div className="md:col-span-8 space-y-6">
                    <div className="bg-white/50 p-6 rounded-2xl border border-vedic-gold/20 shadow-sm">
                      <h4 className="flex items-center gap-2 text-vedic-primary font-serif font-bold text-xl mb-3 border-b border-vedic-gold/10 pb-2">
                        <Stars className="w-5 h-5 text-vedic-accent" /> Personalized Reading
                      </h4>
                      <div className="text-lg italic text-vedic-secondary leading-relaxed text-justify prose prose-sm prose-stone max-w-none">
                        <ReactMarkdown>{data.personalizedReading}</ReactMarkdown>
                      </div>
                    </div>
                  </div>

                  <div className="md:col-span-4 space-y-6">
                    <div className="bg-vedic-primary/5 p-6 rounded-2xl border border-vedic-gold/20 shadow-sm">
                       <h4 className="text-[10px] uppercase font-black text-vedic-accent mb-3 flex items-center gap-2"><Clock className="w-3 h-3" /> Auspicious Muhurta</h4>
                       <p className="font-serif font-bold text-vedic-primary">{data.auspiciousTime}</p>
                    </div>
                    <div className="bg-vedic-primary/5 p-6 rounded-2xl border border-vedic-gold/20 shadow-sm">
                       <h4 className="text-[10px] uppercase font-black text-vedic-accent mb-3 flex items-center gap-2"><Music className="w-3 h-3" /> Daily Mantra</h4>
                       <p className="font-serif italic text-vedic-primary text-sm font-bold">"{data.luckyMantra}"</p>
                    </div>
                  </div>
               </div>

               <div className="grid md:grid-cols-2 gap-6">
                  <div className="bg-emerald-50 p-8 rounded-3xl border border-emerald-100 shadow-sm">
                    <h4 className="font-bold text-emerald-800 mb-4 flex items-center gap-2 uppercase tracking-widest text-xs">
                      <CheckCircle2 className="w-4 h-4" /> Recommended (Dos)
                    </h4>
                    <ul className="space-y-3">
                      {data.dos.map((d,i)=><li key={i} className="text-sm flex items-start gap-2 text-emerald-900 font-medium"><span>•</span> {d}</li>)}
                    </ul>
                  </div>
                  <div className="bg-rose-50 p-8 rounded-3xl border border-rose-100 shadow-sm">
                    <h4 className="font-bold text-rose-800 mb-4 flex items-center gap-2 uppercase tracking-widest text-xs">
                      <AlertCircle className="w-4 h-4" /> Cautions (Donts)
                    </h4>
                    <ul className="space-y-3">
                      {data.donts.map((d,i)=><li key={i} className="text-sm flex items-start gap-2 text-rose-900 font-medium"><span>•</span> {d}</li>)}
                    </ul>
                  </div>
               </div>
             </div>
           ) : (
             <div className="flex flex-col items-center justify-center py-20 opacity-50">
                <AlertCircle className="w-16 h-16 mb-4 text-vedic-highlight" />
                <p className="text-xl font-serif">Celestial alignment interrupted. Please refresh.</p>
             </div>
           )}
        </div>
      </PalmLeafCard>
    </div>
  );
};

export const Matchmaking: React.FC<{ lang: string, onBack: () => void }> = ({ lang, onBack }) => {
  const [p1, setP1] = useState<UserBirthDetails>({ name: '', date: '', time: '', location: '' });
  const [p2, setP2] = useState<UserBirthDetails>({ name: '', date: '', time: '', location: '' });
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<MatchResult | null>(null);

  const calculate = async () => {
    setLoading(true);
    const data = await GeminiService.generateMatchmaking(p1, p2, lang);
    setResult(data);
    setLoading(false);
  };

  return (
    <div className="animate-fade-in pb-12">
      <BackButton onBack={onBack} />
      <PalmLeafCard className="max-w-5xl mx-auto rounded-3xl p-0 overflow-hidden shadow-2xl">
        <div className="bg-vedic-primary p-12 text-center text-white">
           <Heart className="w-16 h-16 mx-auto mb-4 text-vedic-gold animate-pulse" />
           <h2 className="text-5xl font-serif font-bold">Ashtakoota Milan</h2>
        </div>
        <div className="p-10 space-y-10 bg-[#fffdfa]">
           <div className="grid md:grid-cols-2 gap-8">
              <div className="space-y-4 bg-white p-8 rounded-[2rem] border-2 border-vedic-gold/20 shadow-sm">
                 <h3 className="text-xl font-serif font-bold text-vedic-primary border-b pb-4">Person 1</h3>
                 <input className="w-full bg-vedic-light border-2 border-vedic-gold/10 p-4 rounded-2xl outline-none focus:border-vedic-accent" placeholder="Name" value={p1.name} onChange={e=>setP1({...p1, name: e.target.value})} />
                 <div className="grid grid-cols-2 gap-2">
                    <input className="w-full bg-vedic-light border-2 border-vedic-gold/10 p-4 rounded-2xl" type="date" value={p1.date} onChange={e=>setP1({...p1, date: e.target.value})} />
                    <input className="w-full bg-vedic-light border-2 border-vedic-gold/10 p-4 rounded-2xl" type="time" value={p1.time} onChange={e=>setP1({...p1, time: e.target.value})} />
                 </div>
                 <input className="w-full bg-vedic-light border-2 border-vedic-gold/10 p-4 rounded-2xl" placeholder="Place" value={p1.location} onChange={e=>setP1({...p1, location: e.target.value})} />
              </div>
              <div className="space-y-4 bg-white p-8 rounded-[2rem] border-2 border-vedic-gold/20 shadow-sm">
                 <h3 className="text-xl font-serif font-bold text-vedic-primary border-b pb-4">Person 2</h3>
                 <input className="w-full bg-vedic-light border-2 border-vedic-gold/10 p-4 rounded-2xl outline-none focus:border-vedic-accent" placeholder="Name" value={p2.name} onChange={e=>setP2({...p2, name: e.target.value})} />
                 <div className="grid grid-cols-2 gap-2">
                    <input className="w-full bg-vedic-light border-2 border-vedic-gold/10 p-4 rounded-2xl" type="date" value={p2.date} onChange={e=>setP2({...p2, date: e.target.value})} />
                    <input className="w-full bg-vedic-light border-2 border-vedic-gold/10 p-4 rounded-2xl" type="time" value={p2.time} onChange={e=>setP2({...p2, time: e.target.value})} />
                 </div>
                 <input className="w-full bg-vedic-light border-2 border-vedic-gold/10 p-4 rounded-2xl" placeholder="Place" value={p2.location} onChange={e=>setP2({...p2, location: e.target.value})} />
              </div>
           </div>
           <button onClick={calculate} disabled={loading} className="w-full py-6 bg-vedic-primary text-vedic-gold rounded-full font-bold shadow-2xl hover:scale-[1.02] transition-all flex items-center justify-center gap-4 text-2xl uppercase tracking-widest">
              {loading ? <RotateCw className="w-10 h-10 animate-spin" /> : <Sparkles className="w-8 h-8" />} Calculate Union
           </button>
           {result && (
              <div className="animate-fade-in space-y-10">
                 <div className="text-center p-16 bg-white border-8 border-double border-vedic-gold rounded-[4rem] shadow-2xl relative overflow-hidden">
                    <Mandala className="absolute inset-0 opacity-5 pointer-events-none" />
                    <span className="text-xs uppercase font-black text-vedic-accent tracking-[0.5em] mb-4 block">Union Compatibility Score</span>
                    <div className="text-[10rem] font-serif font-bold text-vedic-primary leading-none">{result.score}<span className="text-4xl text-vedic-gold opacity-40 ml-4">/36</span></div>
                    <p className="mt-8 text-xl font-black italic text-vedic-highlight uppercase tracking-[0.2em]">{result.scriptureVerdict}</p>
                 </div>
                 <PalmLeafCard className="rounded-[3rem] border-vedic-paper p-12">
                    <p className="text-xl italic text-justify leading-relaxed text-vedic-secondary">{result.compatibility_analysis}</p>
                 </PalmLeafCard>
              </div>
           )}
        </div>
      </PalmLeafCard>
    </div>
  );
};

export const RemediesPortal: React.FC<{ chart: ChartData, lang: string, onBack: () => void }> = ({ chart, lang, onBack }) => {
  const [remedies, setRemedies] = useState<RemedyData[] | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    GeminiService.generateRemedies(chart, lang).then(data => { setRemedies(data); setLoading(false); });
  }, [chart, lang]);

  return (
    <div className="animate-fade-in pb-12"><BackButton onBack={onBack} />
      <div className="max-w-6xl mx-auto space-y-12">
        <h2 className="text-5xl font-serif font-bold text-vedic-primary text-center">Upaya Shastra</h2>
        {loading ? <div className="py-20 flex flex-col items-center"><RotateCw className="w-16 h-16 animate-spin text-vedic-accent" /></div> : 
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
           {remedies?.map((rem, i) => (
             <PalmLeafCard key={i} className="rounded-[2.5rem] border-0 bg-white/70 backdrop-blur-md shadow-2xl p-8 hover:-translate-y-4 transition-transform">
                <div className="w-16 h-16 bg-vedic-primary text-vedic-gold rounded-full flex items-center justify-center mx-auto mb-6 shadow-xl">
                   {rem.title.toLowerCase().includes('gem') ? <Gem className="w-8 h-8" /> : <Flame className="w-8 h-8" />}
                </div>
                <h3 className="text-xl font-serif font-bold text-vedic-primary mb-4 text-center">{rem.title}</h3>
                <p className="text-sm italic mb-6 leading-relaxed text-center opacity-80">"{rem.description}"</p>
                {rem.mantra && <div className="p-6 bg-vedic-primary/5 rounded-3xl border-2 border-vedic-gold/20 text-center text-sm font-serif font-bold mb-4 italic">"{rem.mantra}"</div>}
                <div className="pt-4 border-t border-vedic-gold/10 text-[10px] uppercase font-black tracking-widest text-center opacity-60">Source: {rem.sourceText}</div>
             </PalmLeafCard>
           ))}
        </div>}
      </div>
    </div>
  );
};

// ... Maintaining ScriptureResearch, RishiCouncil, PalmistryReader, DivineCinema, VisionInterface, AIAgentGuide
// with identical robust structures ...
export const PalmistryReader: React.FC<{ lang: string, onBack: () => void, onComplete: () => void }> = ({ lang, onBack }) => {
  const [image, setImage] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<PalmistryResult | null>(null);
  const handleAnalyze = async () => { if (!image) return; setLoading(true); const res = await GeminiService.generatePalmAnalysis(image, lang); setResult(res); setLoading(false); };
  return (
    <div className="animate-fade-in pb-12"><BackButton onBack={onBack} />
      <PalmLeafCard className="max-w-4xl mx-auto rounded-[3rem] overflow-hidden p-0 shadow-2xl border-vedic-primary">
        <div className="bg-vedic-primary p-12 text-center text-white"><Hand className="w-20 h-20 mx-auto mb-4 text-vedic-gold animate-pulse" /><h2 className="text-4xl font-serif font-bold">Samudrika Shastra</h2></div>
        <div className="p-10 bg-[#fffdfa] space-y-10 min-h-[500px]">
           {!result ? (<div className="flex flex-col items-center gap-10">
              <div className="w-full max-w-lg border-8 border-dashed border-vedic-gold/20 rounded-[3rem] p-20 text-center cursor-pointer hover:bg-vedic-paper/10 transition-all" onClick={() => document.getElementById('palmUpload')?.click()}>
                 <input id="palmUpload" type="file" className="hidden" accept="image/*" onChange={(e) => e.target.files?.[0] && setImage(e.target.files[0])} />
                 {image ? <span className="text-2xl font-bold text-vedic-primary">{image.name}</span> : <div className="opacity-30 flex flex-col items-center"><Upload className="w-20 h-20 mb-4" /><p className="text-3xl font-serif">Upload Hand View</p></div>}
              </div>
              <button onClick={handleAnalyze} disabled={!image || loading} className="px-20 py-6 bg-vedic-primary text-vedic-gold rounded-full font-bold shadow-2xl text-2xl uppercase tracking-widest">{loading ? <RotateCw className="w-8 h-8 animate-spin" /> : 'Read Fate'}</button>
           </div>) : (<div className="space-y-10 animate-fade-in">
              <div className="bg-white p-10 rounded-[3rem] border-4 border-vedic-gold shadow-2xl"><h3 className="text-3xl font-serif font-bold text-vedic-primary mb-6 border-b pb-4">Destiny Vision</h3><p className="text-xl italic text-justify leading-relaxed">{result.overview}</p></div>
              <div className="grid md:grid-cols-2 gap-8">{[{ label: 'Life', text: result.lifeLine }, { label: 'Head', text: result.headLine }, { label: 'Heart', text: result.heartLine }, { label: 'Fate', text: result.fateLine }].map((item, i) => (<div key={i} className="p-10 bg-white rounded-[2.5rem] border-2 border-vedic-gold/10 shadow-lg hover:border-vedic-accent transition-all"><h4 className="font-serif font-bold text-vedic-primary text-2xl mb-4">{item.label} Line</h4><p className="text-sm text-vedic-secondary italic text-justify">"{item.text}"</p></div>))}</div>
              <button onClick={() => setResult(null)} className="w-full py-6 border-4 border-vedic-gold text-vedic-primary font-bold rounded-full text-xl hover:bg-vedic-paper transition-all">NEW ANALYSIS</button>
           </div>)}
        </div>
      </PalmLeafCard>
    </div>
  );
};

export const DivineCinema: React.FC<{ lang: string, onBack: () => void }> = ({ lang, onBack }) => {
  const [prompt, setPrompt] = useState('');
  const [loading, setLoading] = useState(false);
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const handleGenerate = async () => { setLoading(true); const url = await GeminiService.generateVideo(prompt); setVideoUrl(url); setLoading(false); };
  return (
    <div className="animate-fade-in pb-12"><BackButton onBack={onBack} />
      <PalmLeafCard className="max-w-6xl mx-auto rounded-[3.5rem] p-0 overflow-hidden shadow-2xl border-vedic-accent">
        <div className="bg-vedic-primary p-20 text-center text-white"><Video className="w-24 h-24 mx-auto mb-6 text-vedic-gold animate-pulse" /><h2 className="text-6xl font-serif font-bold">Divine Cinema</h2></div>
        <div className="p-10 space-y-10 bg-[#fffdfa]">
           <textarea value={prompt} onChange={e => setPrompt(e.target.value)} placeholder="Describe a spiritual scene..." className="w-full bg-vedic-light border-4 border-vedic-gold/10 rounded-[3rem] p-10 text-2xl text-vedic-primary font-serif italic h-56 shadow-inner outline-none focus:border-vedic-accent" />
           <button onClick={handleGenerate} disabled={loading || !prompt.trim()} className="w-full py-8 bg-vedic-primary text-vedic-gold rounded-full font-bold shadow-2xl text-3xl uppercase tracking-widest">{loading ? <RotateCw className="w-10 h-10 animate-spin" /> : 'Manifest Vision'}</button>
           {videoUrl && <div className="rounded-[4rem] overflow-hidden shadow-2xl border-[16px] border-vedic-gold bg-black"><video src={videoUrl} controls className="w-full aspect-video" autoPlay loop /></div>}
        </div>
      </PalmLeafCard>
    </div>
  );
};

export const RishiCouncil: React.FC<{ chart: ChartData, lang: string, onBack: () => void }> = ({ chart, lang, onBack }) => {
  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<CouncilWisdom | null>(null);
  const handleConsult = async () => { setLoading(true); const res = await GeminiService.getRishiCouncilAdvice(chart, query, lang); setResult(res); setLoading(false); };
  return (
    <div className="animate-fade-in pb-12"><BackButton onBack={onBack} />
      <PalmLeafCard className="max-w-5xl mx-auto rounded-[3.5rem] overflow-hidden p-0 shadow-2xl">
        <div className="bg-gradient-to-r from-vedic-primary to-vedic-secondary p-16 text-center text-white"><Users className="w-24 h-24 mx-auto mb-6 text-vedic-gold" /><h2 className="text-5xl font-serif font-bold">Rishi Parishad</h2></div>
        <div className="p-10 space-y-12 bg-[#fffdfa]">
           <div className="flex flex-col md:flex-row gap-6"><input value={query} onChange={e => setQuery(e.target.value)} placeholder="Present your life query..." className="flex-1 bg-white border-4 border-vedic-gold/20 rounded-[2.5rem] px-10 py-6 text-2xl font-serif italic outline-none shadow-inner focus:border-vedic-accent" /><button onClick={handleConsult} disabled={loading} className="bg-vedic-primary text-vedic-gold px-12 py-6 rounded-full font-bold shadow-2xl text-2xl">{loading ? <RotateCw className="w-8 h-8 animate-spin" /> : 'Consult'}</button></div>
           {result && (<div className="space-y-12 animate-fade-in"><div className="grid md:grid-cols-3 gap-10">{result.discussion.map((r, i) => (<div key={i} className="bg-white p-10 rounded-[3rem] border-b-[12px] border-vedic-highlight shadow-2xl hover:scale-105 transition-all"><h4 className="font-serif font-bold text-vedic-primary text-2xl mb-6 border-b-2 pb-4">{r.agentName}</h4><p className="text-lg text-vedic-secondary italic text-justify leading-relaxed">"{r.wisdom}"</p></div>))}</div><div className="bg-vedic-primary p-20 rounded-[4rem] text-white shadow-2xl border-[6px] border-vedic-gold relative overflow-hidden"><Mandala className="absolute inset-0 opacity-5" /><h3 className="text-5xl font-serif font-bold text-vedic-gold mb-8 border-b border-vedic-gold/30 pb-6">Final Decree</h3><ReactMarkdown className="prose prose-invert prose-lg max-w-none text-2xl text-vedic-light italic font-serif leading-relaxed text-justify">{result.finalDecree}</ReactMarkdown></div></div>)}
        </div>
      </PalmLeafCard>
    </div>
  );
};

export const ScriptureResearch: React.FC<{ lang: string, onBack: () => void }> = ({ lang, onBack }) => {
  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<ResearchResult | null>(null);
  const handleResearch = async () => { setLoading(true); const res = await GeminiService.researchScriptures(query, lang); setResult(res); setLoading(false); };
  return (
    <div className="animate-fade-in pb-12"><BackButton onBack={onBack} />
      <div className="max-w-5xl mx-auto space-y-12 text-center">
        <Search className="w-24 h-24 mx-auto text-vedic-accent animate-pulse" /><h2 className="text-6xl font-serif font-bold text-vedic-primary">Jyotish Shastra Research</h2>
        <div className="flex flex-col md:flex-row gap-6"><input value={query} onChange={e => setQuery(e.target.value)} placeholder="Concept (e.g., Sade Sati)..." className="flex-1 bg-white border-8 border-vedic-gold/10 rounded-[3rem] px-12 py-8 text-3xl font-serif outline-none shadow-2xl" /><button onClick={handleResearch} disabled={loading} className="bg-vedic-primary text-vedic-gold px-16 py-8 rounded-full font-bold shadow-2xl text-2xl flex items-center gap-4">{loading ? <RotateCw className="w-10 h-10 animate-spin" /> : <BookOpen className="w-8 h-8" />} Explore</button></div>
        {result && (<div className="animate-fade-in space-y-10"><PalmLeafCard className="rounded-[4rem] bg-white/80 shadow-2xl p-20"><ReactMarkdown className="prose prose-2xl max-w-none text-justify text-vedic-primary font-serif leading-relaxed">{result.text}</ReactMarkdown></PalmLeafCard></div>)}
      </div>
    </div>
  );
};

export const VisionInterface: React.FC<{ onBack: () => void }> = ({ onBack }) => {
  const [prompt, setPrompt] = useState('');
  const [loading, setLoading] = useState(false);
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const handleGenerate = async () => { setLoading(true); const url = await GeminiService.generateVision(prompt); setImageUrl(url); setLoading(false); };
  return (
    <div className="animate-fade-in pb-12"><BackButton onBack={onBack} />
      <PalmLeafCard className="max-w-5xl mx-auto rounded-[3.5rem] p-0 overflow-hidden shadow-2xl">
        <div className="bg-gradient-to-br from-vedic-highlight to-vedic-accent p-20 text-center text-white"><ImageIcon className="w-24 h-24 mx-auto mb-6 animate-pulse" /><h2 className="text-6xl font-serif font-bold">Darshan Manifestation</h2></div>
        <div className="p-16 space-y-12 bg-[#fffdfa]">
           <input value={prompt} onChange={e => setPrompt(e.target.value)} placeholder="Invoke a form (e.g., 'Golden Surya')..." className="w-full bg-white border-8 border-vedic-gold/10 rounded-full px-16 py-8 text-3xl font-serif italic outline-none shadow-2xl text-center" />
           <button onClick={handleGenerate} disabled={loading || !prompt.trim()} className="w-full py-10 bg-vedic-primary text-vedic-gold rounded-full font-bold shadow-2xl text-4xl uppercase tracking-[0.2em]">{loading ? <RotateCw className="w-12 h-12 animate-spin" /> : <Sparkles className="w-12 h-12" />}</button>
           {imageUrl && (<div className="animate-fade-in flex flex-col items-center gap-12"><div className="p-6 bg-white border-[16px] border-vedic-gold rounded-[5rem] shadow-2xl max-w-3xl w-full"><img src={imageUrl} alt="Darshan" className="w-full rounded-[3.5rem] shadow-inner" /></div><a href={imageUrl} download="SacredDarshan.png" className="bg-vedic-primary text-vedic-gold px-20 py-6 rounded-full font-black text-2xl uppercase shadow-2xl">Preserve Vision</a></div>)}
        </div>
      </PalmLeafCard>
    </div>
  );
};

export const AIAgentGuide: React.FC<{ onBack: () => void }> = ({ onBack }) => (
  <div className="animate-fade-in pb-12"><BackButton onBack={onBack} /><PalmLeafCard className="max-w-5xl mx-auto rounded-[4rem] border-8 border-vedic-gold p-20 shadow-2xl"><h2 className="text-6xl font-serif font-bold text-vedic-primary mb-12 text-center border-b-4 border-vedic-accent pb-8">Agent Shastra</h2><div className="space-y-16 text-3xl text-vedic-secondary leading-relaxed italic text-justify font-serif"><p>1. The AI is a divine mirror of the cosmic archives.</p><p>2. Pure intent manifests pure clarity.</p><p>3. Every sutra is a potentiality, not a mandate.</p></div></PalmLeafCard></div>
);

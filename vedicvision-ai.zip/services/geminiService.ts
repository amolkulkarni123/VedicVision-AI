
import { GoogleGenAI } from "@google/genai";
import { 
  ChartData, MatchResult, RemedyData, PalmistryResult, UserBirthDetails, 
  CouncilWisdom, ResearchResult, DailyHoroscopeData
} from "../types";

const MODEL_REASONING = 'gemini-3.5-flash';
const MODEL_FAST = 'gemini-3.5-flash';
const MODEL_VISION = 'gemini-3.5-flash'; 
const MODEL_IMAGE_GEN = 'gemini-2.5-flash-image';
const MODEL_VIDEO = 'veo-3.1-lite-generate-preview';
const MODEL_RESEARCH = 'gemini-3.5-flash';

const MAX_RETRIES = 2;

async function fetchWithRetry<T>(fn: () => Promise<T>, retries = MAX_RETRIES): Promise<T | null> {
  try {
    return await fn();
  } catch (error: any) {
    // Retry on rate limits (429) or server errors (500+)
    if (retries > 0 && (error?.status === 429 || error?.status >= 500)) {
      const wait = Math.pow(2, MAX_RETRIES - retries + 1) * 1000;
      await new Promise(r => setTimeout(r, wait));
      return fetchWithRetry(fn, retries - 1);
    }
    // Specific check for Permission Denied (403) or Unauthorized (401)
    await handleError(error);
    throw error;
  }
}

const handleError = async (error: any) => {
  const errorMsg = error?.message || "";
  const status = error?.status;

  console.error("VedicVision Service Layer Error:", { status, message: errorMsg });

  // 403 (Permission Denied) and 401 (Unauthorized) usually mean the key is missing/invalid or restricted
  // 404 (Not Found) can happen if a model is deprecated or the project is misconfigured
  const isPermissionIssue = status === 403 || status === 401 || errorMsg.includes("permission") || errorMsg.includes("not found");

  if (isPermissionIssue) {
    if (window.aistudio && typeof window.aistudio.openSelectKey === 'function') {
      try {
        await window.aistudio.openSelectKey();
      } catch (e) {
        console.warn("Key selection dialog was closed or failed.");
      }
    }
  }
};

export const GeminiService = {
  
  // Rule: Always create a fresh instance right before making an API call to use latest key
  getAI() {
    const key = process.env.API_KEY || process.env.GEMINI_API_KEY;
    if (!key || key === 'undefined' || key === 'null') {
      throw { status: 403, message: "API Key is missing or undefined" };
    }
    return new GoogleGenAI({ 
      apiKey: key,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  },

  /**
   * Production Pre-flight check.
   * Checks for 403 errors and validates model access.
   */
  async checkCelestialHealth(): Promise<'online' | 'restricted' | 'offline'> {
    try {
      const ai = this.getAI();
      const response = await ai.models.generateContent({
        model: MODEL_FAST,
        contents: "Respond with 'READY'.",
        config: { 
          maxOutputTokens: 50
        }
      });
      return response.text?.includes("READY") ? 'online' : 'offline';
    } catch (e: any) {
      if (e?.status === 403 || e?.status === 401) return 'restricted';
      return 'offline';
    }
  },

  async generateBirthChart(details: UserBirthDetails, lang: string): Promise<ChartData | null> {
    const ai = this.getAI();
    const prompt = `Role: Param-Jyotish Acharya. 
    Analyze birth chart for ${details.name}, DOB: ${details.date} ${details.time}, Place: ${details.location}. Lang: ${lang}. 
    Reference Brihat Parashara Hora Shastra.
    Return strict JSON:
    - ascendant: string
    - summary: Markdown reading with Sanskrit citations.
    - scriptureCitations: string[]
    - charts: { d1: PlanetPosition[], d9: PlanetPosition[], d10: PlanetPosition[] }
    - currentDasha: { planet, startDate, endDate, prediction, scriptureRef }
    - loshu: { grid: (number|null)[], strengths: string[], weaknesses: string[], missingNumbersAnalysis: string }
    - forecasts: YearlyForecast[]`;
    
    return fetchWithRetry(async () => {
      const response = await ai.models.generateContent({
        model: MODEL_REASONING,
        contents: prompt,
        config: { responseMimeType: 'application/json' }
      });
      return response.text ? JSON.parse(response.text) : null;
    });
  },

  async generateDailyHoroscope(chart: ChartData, lang: string): Promise<DailyHoroscopeData | null> {
    const ai = this.getAI();
    const today = new Date().toISOString().split('T')[0];
    const transits = await this.generateTransits(today);
    
    const prompt = `Today: ${today}. Gochara: ${transits}. Ascendant: ${chart.ascendant}.
    Provide daily personalized horoscope. Lang: ${lang}.
    Return JSON: { cosmicMood, personalizedReading, scriptureSutra, dos:[], donts:[], luckyMantra, auspiciousTime }`;

    return fetchWithRetry(async () => {
      const response = await ai.models.generateContent({
        model: MODEL_FAST,
        contents: prompt,
        config: { responseMimeType: 'application/json' }
      });
      return response.text ? JSON.parse(response.text) : null;
    });
  },

  async generateTransits(date: string): Promise<string | null> {
    const ai = this.getAI();
    return fetchWithRetry(async () => {
      const response = await ai.models.generateContent({
        model: MODEL_FAST,
        contents: `Major Vedic planetary transits for ${date}. Concise summary.`
      });
      return response.text || null;
    });
  },

  async generateMatchmaking(p1: UserBirthDetails, p2: UserBirthDetails, lang: string): Promise<MatchResult | null> {
    const ai = this.getAI();
    return fetchWithRetry(async () => {
      const response = await ai.models.generateContent({
        model: MODEL_REASONING,
        contents: `Ashtakoota Milan: ${p1.name} & ${p2.name}. JSON. Lang: ${lang}`,
        config: { responseMimeType: 'application/json' }
      });
      return response.text ? JSON.parse(response.text) : null;
    });
  },

  async generateRemedies(chart: ChartData, lang: string): Promise<RemedyData[] | null> {
    const ai = this.getAI();
    return fetchWithRetry(async () => {
      const response = await ai.models.generateContent({
        model: MODEL_FAST,
        contents: `Upayas for ${chart.ascendant} ascendant. JSON array. Lang: ${lang}`,
        config: { responseMimeType: 'application/json' }
      });
      return response.text ? JSON.parse(response.text) : null;
    });
  },

  async generateVideo(prompt: string): Promise<string | null> {
    const ai = this.getAI();
    try {
      let operation = await ai.models.generateVideos({
        model: MODEL_VIDEO,
        prompt: `Cinematic spiritual vision: ${prompt}`,
        config: { numberOfVideos: 1, resolution: '1080p', aspectRatio: '16:9' }
      });
      while (!operation.done) {
        await new Promise(resolve => setTimeout(resolve, 10000));
        operation = await ai.operations.getVideosOperation({operation: operation});
      }
      const res = await fetch(`${operation.response?.generatedVideos?.[0]?.video?.uri}&key=${process.env.API_KEY}`);
      const blob = await res.blob();
      return URL.createObjectURL(blob);
    } catch (e) { 
      await handleError(e);
      return null;
    }
  },

  async generateVision(prompt: string): Promise<string | null> {
    const ai = this.getAI();
    try {
      const response = await ai.models.generateContent({
        model: MODEL_IMAGE_GEN,
        contents: { parts: [{ text: `Vedic Darshan: ${prompt}` }] },
        config: { imageConfig: { aspectRatio: "1:1" } }
      });
      const part = response.candidates?.[0]?.content?.parts.find(p => p.inlineData);
      return part ? `data:image/png;base64,${part.inlineData.data}` : null;
    } catch (e) {
      await handleError(e);
      return null;
    }
  },

  async getRishiCouncilAdvice(chart: ChartData, query: string, lang: string): Promise<CouncilWisdom | null> {
    const ai = this.getAI();
    return fetchWithRetry(async () => {
      const response = await ai.models.generateContent({
        model: MODEL_REASONING,
        contents: `Rishi debate: "${query}" for ${chart.ascendant} ascendant. JSON. Lang: ${lang}`,
        config: { responseMimeType: 'application/json' }
      });
      return response.text ? JSON.parse(response.text) : null;
    });
  },

  async researchScriptures(query: string, lang: string): Promise<ResearchResult | null> {
    const ai = this.getAI();
    try {
      const response = await ai.models.generateContent({
        model: MODEL_RESEARCH,
        contents: `Vedic verses for: ${query}. Lang: ${lang}.`,
        config: { tools: [{ googleSearch: {} }] }
      });
      const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
      return {
        text: response.text || "No records found.",
        sources: chunks.filter(c => c.web).map(c => ({ title: c.web!.title, uri: c.web!.uri }))
      };
    } catch (e) {
      await handleError(e);
      return null;
    }
  },

  async generatePalmAnalysis(imageFile: File, lang: string): Promise<PalmistryResult | null> {
    const ai = this.getAI();
    const base64Data = await new Promise<string>((resolve) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve((reader.result as string).split(',')[1]);
      reader.readAsDataURL(imageFile);
    });
    return fetchWithRetry(async () => {
      const response = await ai.models.generateContent({
        model: MODEL_VISION,
        contents: { parts: [{ inlineData: { mimeType: imageFile.type, data: base64Data } }, { text: `Vedic Samudrika Shastra. JSON. Lang: ${lang}` }] },
        config: { responseMimeType: 'application/json' }
      });
      return response.text ? JSON.parse(response.text) : null;
    });
  },

  async chatStream(history: any[], message: string, lang: string) {
    const ai = this.getAI();
    const chat = ai.chats.create({ 
      model: MODEL_FAST, 
      history,
      config: { systemInstruction: `You are a Mahayogi expert in Vedas and Jyotish. Lang: ${lang}` } 
    });
    return chat.sendMessageStream({ message });
  }
};
